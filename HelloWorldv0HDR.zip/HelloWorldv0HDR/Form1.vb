﻿Imports System.Runtime.CompilerServices
' Write A ToonEMU 1.0A [C] - Flames Reality LLC
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Import the System.Drawing namespace to use Color


        ' Get a reference to the form
        Dim form As Form = Me

        ' Change the background color to the Steam layout color
        form.BackColor = Color.FromArgb(61, 60, 76)


        form.MaximizeBox = False

        form.MaximizeBox = False
        form.Text = "GPT-X LSTM 1.0a [C] - Haltmann Works 20XX"



    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        ' Write me a program

        If CheckBox1.Checked Then
            CheckBox1.Checked = False
            MessageBox.Show("Debugging problem")
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged

        If CheckBox1.Checked Then


            CheckBox3.Checked = False
            MessageBox.Show("Okay human 1.0a")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        '' Now quitting
        Me.Close()
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        ' Import the System.Windows.Forms namespace to use MessageBox

        ' Make CheckBox2.Checked false
        If CheckBox2.Checked = True Then
            CheckBox2.Checked = False
            MessageBox.Show("This is debugging over")
        End If


    End Sub
End Class
